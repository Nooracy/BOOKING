package Entity;

public class FlightSeat extends Seat{
	public int Number;
	public boolean Position;

}
