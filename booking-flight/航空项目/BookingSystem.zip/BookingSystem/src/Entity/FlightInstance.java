package Entity;


public class FlightInstance extends Flight{
	
}
