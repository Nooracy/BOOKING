package Entity;

public class Trip {
	public int TotalFare;
	public Passenger passenger=new Passenger();
	public Flight flight;

}
