package Entity;

public class Passenger {
	public String Name;
	public int PassportNumber;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getPassportNumber() {
		return PassportNumber;
	}
	public void setPassportNumber(int passportNumber) {
		PassportNumber = passportNumber;
	}

}
