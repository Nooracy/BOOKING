package Entity;

public abstract class Seat {
	public int Line;
	public int Row;

}
