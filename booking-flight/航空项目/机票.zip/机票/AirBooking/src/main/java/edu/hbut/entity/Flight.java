package edu.hbut.entity;

import lombok.Data;

import java.util.Date;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Flight {
    private int number;
    private Date departuretime;
    private Date arrivaltime;
    private double fare;
    private int dportCode;
    private int aportCode;
    private int airline;
    private int plane;



}
