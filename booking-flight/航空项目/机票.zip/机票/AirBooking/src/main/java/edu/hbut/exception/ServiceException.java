package edu.hbut.exception;

import lombok.Getter;

public class ServiceException extends RuntimeException{

    private static final long serialVersionUID = -7243774691044598098L;

    @Getter
    private final int code;

    public ServiceException(int code) {
        this.code = code;
    }

    public ServiceException(int code, Throwable throwable) {
        super(throwable);
        this.code = code;
    }

    public ServiceException(int code, String message) {
        super(message);
        this.code = code;
    }

    public ServiceException(int code, String message, Throwable throwable) {
        super(message, throwable);
        this.code = code;
    }

    public ServiceException(ErrorCode errorCode) {
        super(errorCode.getMessage());
        this.code = errorCode.getCode();
    }

    public ServiceException(ErrorCode errorCode, Throwable cause) {
        super(errorCode.getMessage(),cause);
        this.code = errorCode.getCode();
    }
}
