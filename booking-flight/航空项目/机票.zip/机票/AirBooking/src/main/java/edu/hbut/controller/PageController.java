package edu.hbut.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by dy on 2017/11/18.
 */

@Controller
public class PageController {

    @RequestMapping("home")
    public ModelAndView home(){
        ModelAndView modelAndView = new ModelAndView("home");
        return modelAndView;
    }
    @RequestMapping("Result")
    public ModelAndView Result(){
        ModelAndView modelAndView = new ModelAndView("Result");
        return modelAndView;
    }
    @RequestMapping("SelectSeat")
    public ModelAndView SelectSeat(){
        ModelAndView modelAndView = new ModelAndView("SelectSeat");
        return modelAndView;
    }
    @RequestMapping("message")
    public ModelAndView message(){
        ModelAndView modelAndView = new ModelAndView("message");
        return modelAndView;
    }
    @RequestMapping("pay")
    public ModelAndView pay(){
        ModelAndView modelAndView = new ModelAndView("pay");
        return modelAndView;
    }
    @RequestMapping("receipt")
    public ModelAndView receipt(){
        ModelAndView modelAndView = new ModelAndView("receipt");
        return modelAndView;
    }
}
