package edu.hbut.controller.aop;

import com.google.common.base.Throwables;
import edu.hbut.dto.response.Response;
import edu.hbut.exception.ErrorCode;
import edu.hbut.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@Component
@Aspect
@Slf4j
public class ControllerAspect {

    private final LocalValidatorFactoryBean localValidatorFactoryBean ;

    @Autowired
    public ControllerAspect(LocalValidatorFactoryBean localValidatorFactoryBean) {
        this.localValidatorFactoryBean = localValidatorFactoryBean;
    }

    @Around("execution(public edu.hbut.dto.response.Response edu.hbut.controller.*Controller.*(..))")
    public Response serviceAccess(ProceedingJoinPoint joinPoint) {
        StopWatch stopWatch = new StopWatch(); //用来计算方法耗时
        stopWatch.start();
        Response response = null;
        String interfaceName = joinPoint.getSignature().getDeclaringTypeName();
        String methodName = joinPoint.getSignature().getName();
        String controllerName = interfaceName + "." + methodName;

        //获得参数列表
        Object[] args = joinPoint.getArgs();
        if (args != null) {
            Object argObject = args[0];
            log.info("Start to handle {}, PARAMETER: {}", controllerName, argObject);
            try {
                response = (Response) joinPoint.proceed(); //再业务执行
                stopWatch.stop();
                log.info("Finish handling {}, RESULT: {}, ELAPSED: {}" , controllerName, response, stopWatch);
            } catch (ServiceException e) {
                //逻辑错误
                response = new Response<>(e.getCode(), e.getMessage(), null);
                stopWatch.stop();
                log.info("Failed to call {} , RESULT: {}, ELAPSED: {}", controllerName, response, stopWatch);
            } catch (DataAccessException e) {
                //数据库有问题
                response = new Response<>(ErrorCode.ERROR_CODE_50002.getCode(),
                        ErrorCode.ERROR_CODE_50002.getMessage(), null);
                stopWatch.stop();
                log.info("Failed to call {}, RESULT: {}, ELAPSED: {}", controllerName, response, stopWatch);
                log.error("Failed to call {}, RESULT: {}, \r\nCAUSE: {}", controllerName, response, Throwables.getStackTraceAsString(e));
            } catch (Throwable throwable) {
                //内部错误
                response = new Response<>(ErrorCode.ERROR_CODE_50001.getCode(),
                        ErrorCode.ERROR_CODE_50001.getMessage(), null);
                stopWatch.stop();
                log.info("Failed to call {}, RESULT: {}, ELAPSED: {}", controllerName, response, stopWatch);
                log.error("Failed to call {}, RESULT: {}, \r\nCAUSE: {}", controllerName, response, Throwables.getStackTraceAsString(throwable));
            }
        }
        return response;
    }

}
