package edu.hbut.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCode {

    ERROR_CODE_40000(40000,"传入参数不正确"),
    ERROR_CODE_40001(40001,"该用户名已存在"),
    ERROR_CODE_40002(40002,"该邮箱不存在"),
    ERROR_CODE_40003(40003,"参数不能为空"),
    ERROR_CODE_40004(40004,"该邮箱已经注册请登录"),
    ERROR_CODE_50001(50001,"服务器忙,请稍后再试"),
    ERROR_CODE_50002(50002,"资源忙，请稍后再试"),
    ERROR_CODE_50003(50003, "网络出错，请稍后再试"),
    ERROR_CODE_50005(50005, "URL编码解码出错");

    private int code;
    private String message;

}
