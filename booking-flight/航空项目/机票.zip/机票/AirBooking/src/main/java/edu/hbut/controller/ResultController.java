package edu.hbut.controller;

import edu.hbut.dto.request.ResearDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/**
 * Created by dy on 2017/11/21.
 */
@Controller
@Slf4j
@RequestMapping("controller/result")
public class ResultController {

    @RequestMapping("entermessage")
    public String entermessage(HttpSession session, ResearDTO researDTO, String destination,String originPort,Model model){
        int people=(int) session.getAttribute("people");  //取出旅客数就可以进行加载前面div框了
        System.out.println(people);
        System.out.println(researDTO.toString());
        session.setAttribute("researDTO",researDTO);
        session.setAttribute("originPort",originPort);
        session.setAttribute("destination",destination);
        session.setAttribute("number",researDTO.getNumber());
        return "redirect:/controller/message/searchport";

    }
}
