package edu.hbut.service.impl;

import edu.hbut.dao.SelectMapper;
import edu.hbut.dto.request.PassengerDTO;
import edu.hbut.entity.FlySeat;
import edu.hbut.service.SelectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by dy on 2017/11/22.
 */
@Service
@Slf4j
public class SelectServiceImpl implements SelectService {

    private SelectMapper selectDao;

    @Autowired
    public SelectServiceImpl(SelectMapper selectDao){
        this.selectDao=selectDao;
    }


    @Override
    public void insertPassenger(PassengerDTO passengerDTO) {
        System.out.println("我进入service里面了");
        System.out.println(passengerDTO.toString());
        selectDao.insertPassenger(passengerDTO);  //这个调用数据库的插入passenger语句

    }

    @Override
    public List<FlySeat> seatstate(Integer number) {
        System.out.println("我在SelectServiceImpl中的seatstate");
        System.out.println(number);
        List<FlySeat> seatstatelist=selectDao.seatstate(number);
        return  seatstatelist;
    }
}
