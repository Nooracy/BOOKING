package edu.hbut.entity;

import lombok.Data;

import java.util.Date;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Order {
    private int ordCode;
    private int apassId;
    private int instanCode;
    private Date ordTime;
}
