package edu.hbut.dto.request;

import lombok.Data;

/**
 * Created by dy on 2017/11/22.
 */
@Data
public class PassengerDTO {
    private String passCredit;  //乘客身份证号
    private String passName;  //乘客姓名
    private String passTel;  //乘客联系方式
}
