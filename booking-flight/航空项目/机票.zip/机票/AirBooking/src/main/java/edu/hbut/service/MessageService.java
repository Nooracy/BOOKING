package edu.hbut.service;

import edu.hbut.dto.request.PlaneDTO;

/**
 * Created by dy on 2017/11/22.
 */
public interface MessageService {
    PlaneDTO search(int number);
}
