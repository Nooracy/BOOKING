package edu.hbut.dto.request;

import lombok.Data;

import java.sql.Date;

/**
 * Created by dy on 2017/11/20.
 */
@Data
public class ResearDTO {
    private int number;    //这个是航班的编号暂时是int型之后加一个航班id这个换成C12458这样的东西
    private String lineName;  //这个是航空公司的名字
    private String airName;  //这个是飞机的名称
    private Date departuretime;  //这个是飞机起飞的时间（注意是用来获取数据库的值所以给的是sql包的）
    private Date arrivaltime; // 这个是飞机降落时间（同上）
    private Double fare;   //这个是航班价格
    private Date insDate;   //这个是航班起飞时间
}
