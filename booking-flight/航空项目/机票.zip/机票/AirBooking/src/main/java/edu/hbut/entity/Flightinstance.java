package edu.hbut.entity;

import lombok.Data;

import java.util.Date;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Flightinstance {
    private int insCode;
    private int flightNumber;
    private Date insDate;
    private int flyType;

}
