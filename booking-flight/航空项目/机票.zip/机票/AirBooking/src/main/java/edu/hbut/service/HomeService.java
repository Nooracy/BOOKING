package edu.hbut.service;

import edu.hbut.dto.request.HomeDTO;
import edu.hbut.dto.request.ResearDTO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by dy on 2017/11/19.
 */
public interface HomeService {
   List<ResearDTO> search(HomeDTO homeDTO);
}
