package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class FlySeat {
    private int flySeatCode;
    private int aseatCode;
    private int ainsCode;
    private int seatEmpty;   //给一个座位值来标记这个座位是否被选中


}
