package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Airline {
    private int lineCode;
    private String lineName;
    private float owndiscount;
}
