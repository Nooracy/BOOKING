package edu.hbut.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * Created by dy on 2017/11/22.
 */

@Component
public interface MessageMapper {


    String finddecity(@Param("number") int number);  //这个是找离开城市的名字

    String findacity(@Param("number2") int number);   //这个是找抵达城市的名字
}
