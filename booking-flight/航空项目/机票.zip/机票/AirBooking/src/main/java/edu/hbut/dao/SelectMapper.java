package edu.hbut.dao;

import edu.hbut.dto.request.PassengerDTO;
import edu.hbut.entity.FlySeat;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by dy on 2017/11/22.
 */

@Component
public interface SelectMapper {
    void insertPassenger(@Param("passenger") PassengerDTO passengerDTO);

    List<FlySeat> seatstate(@Param("number") int number);
}
