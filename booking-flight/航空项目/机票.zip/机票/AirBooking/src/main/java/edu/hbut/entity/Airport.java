package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Airport {
    private int portCode;
    private String portName;
    private String portCity;
    private String portCountry;
    private int conTime;
}
