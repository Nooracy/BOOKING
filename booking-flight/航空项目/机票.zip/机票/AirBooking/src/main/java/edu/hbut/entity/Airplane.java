package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Airplane {
    private int airCode;
    private int alineCode;
    private String airType;
    private String airName;
}
