package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Seat {
    private int seatCode;
    private int aplaneCode;
    private String seatRow;
    private String seatNumber;
    private String seatType;
}
