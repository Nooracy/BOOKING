package edu.hbut.entity;

import lombok.Data;

/**
 * Created by dy on 2017/11/18.
 */
@Data
public class Passenger {
    private int passId;
    private int aflySeatCode;
    private String passCredit;
    private String passName;
    private String passTel;
}
