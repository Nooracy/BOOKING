package edu.hbut.controller;

import edu.hbut.dto.request.PassengerDTO;
import edu.hbut.dto.request.PlaneDTO;
import edu.hbut.dto.request.ResearDTO;
import edu.hbut.entity.FlySeat;
import edu.hbut.service.MessageService;
import edu.hbut.service.SelectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;
import java.util.List;

/**
 * Created by dy on 2017/11/22.
 */

@Controller
@Slf4j
@RequestMapping("controller/select")
public class SelectController {
    @Autowired
    SelectService selectService;

    @Autowired
    MessageService messageService;

    @RequestMapping("insertPassenger")
    public String insertPassenger(PassengerDTO passengerDTO,HttpSession session,Model model){
        int number=(int)session.getAttribute("number");
        ResearDTO researDTO=(ResearDTO)session.getAttribute("researDTO");
        String originPort=(String)session.getAttribute("originPort");
        String destination=(String)session.getAttribute("destination");
        int people=(int) session.getAttribute("people");
//        把它送到前端去
        model.addAttribute("researDTO",researDTO);
        model.addAttribute("originPort",originPort);
        model.addAttribute("destination",destination);
        model.addAttribute("people",people);

        System.out.println("123");
        PlaneDTO planeDTO = messageService.search(number);
        System.out.println(planeDTO.toString());
        model.addAttribute("planeDTO",planeDTO);
        System.out.println("我进入insertPassenger");
        selectService.insertPassenger(passengerDTO);

        return "SelectSeat";

    }

   /* @PostMapping("seatstate")
    public List<FlySeat> seatstate(HttpSession session,Model model){

        System.out.println("我进入了seatstate12");
        int number=(int)session.getAttribute("number");
        List<FlySeat> seatstatelist=selectService.seatstate(number);
        System.out.println(seatstatelist.get(0));
        return seatstatelist;
    }*/

   @RequestMapping("seatstate")
   @ResponseBody
   public List<FlySeat> seatstate(HttpSession session){
       System.out.println("我进入到了seatstate的controller里面了");
       int number = (int)session.getAttribute("number");
       List<FlySeat> seatstateList = selectService.seatstate(number);
       System.out.println(seatstateList.get(0));
       return seatstateList;
   }

    @RequestMapping("jumppay")
    public String jumppay(){
        return "pay";
    }

    @RequestMapping("jumpreceipt")
    public String jumpreceipt(){
        return "receipt";
    }
}
