package edu.hbut.dao;

import edu.hbut.dto.request.HomeDTO;
import edu.hbut.dto.request.ResearDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by dy on 2017/11/20.
 */

@Component
public interface HomeMapper  {

    Boolean queryinstan(@Param("homeDTO") HomeDTO homeDTO);

    List<ResearDTO> search(@Param("homeDTO2") HomeDTO homeDTO);
}
