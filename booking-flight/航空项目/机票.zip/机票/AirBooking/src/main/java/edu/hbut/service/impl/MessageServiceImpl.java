package edu.hbut.service.impl;

import edu.hbut.dao.MessageMapper;
import edu.hbut.dto.request.PlaneDTO;
import edu.hbut.service.MessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by dy on 2017/11/22.
 */
@Service
@Slf4j
public class MessageServiceImpl implements MessageService {

    private MessageMapper messagedao;

    @Autowired
    public MessageServiceImpl(MessageMapper messagedao){
        this.messagedao=messagedao;
    }

    @Override
    public PlaneDTO search(int number) {
        String deportname = messagedao.finddecity(number);
        String aportname = messagedao.findacity(number);
        System.out.println(deportname);
        PlaneDTO planeDTO = new PlaneDTO();
        planeDTO.setDportName(deportname);
        planeDTO.setAportName(aportname);
        return planeDTO;


    }
}
