package edu.hbut.dto.request;

import lombok.Data;

import java.util.Date;


/**
 * Created by dy on 2017/11/18.
 */
@Data
public class HomeDTO {
    private String originPort;  //起飞机场
    private String destination;  //落地机场
    private Date departuretime; //出发时间
    private int people;  //乘坐人数
}
