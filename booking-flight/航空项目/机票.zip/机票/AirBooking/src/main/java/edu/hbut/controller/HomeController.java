package edu.hbut.controller;

import edu.hbut.dto.request.HomeDTO;
import edu.hbut.dto.request.ResearDTO;
import edu.hbut.service.HomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by dy on 2017/11/19.
 */

@Controller
@Slf4j
@RequestMapping("controller/home")
public class HomeController {
    @Autowired
    HomeService homeService;

    @RequestMapping("search")
    public String search(HomeDTO homeDTO,Model model,HttpSession session){
        //首先我也要直接传值
        System.out.println("我进来了~");

        //这一部分直接转发给Result页面不需要进后台处理
        model.addAttribute("originPort",homeDTO.getOriginPort());
        model.addAttribute("destination",homeDTO.getDestination());
        model.addAttribute("people",homeDTO.getPeople());
        session.setAttribute("people",homeDTO.getPeople()); //这个地方存一个人数值便于后面使用

        //开始进入后台
        List<ResearDTO> researDTOList=homeService.search(homeDTO);  //接住这个list
        model.addAttribute("researDTOList",researDTOList);  //把这个list往前台传递

        return "Result";
    }


}
