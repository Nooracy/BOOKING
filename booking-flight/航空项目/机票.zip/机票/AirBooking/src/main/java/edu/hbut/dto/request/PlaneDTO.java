package edu.hbut.dto.request;

import lombok.Data;

/**
 * Created by dy on 2017/11/22.
 */
@Data
public class PlaneDTO {
    private String dportName;  //这个是飞机的离开城市
    private String aportName;   //这个是飞机抵达城市
}
