package edu.hbut.service.impl;

import edu.hbut.dao.HomeMapper;
import edu.hbut.dto.request.HomeDTO;
import edu.hbut.dto.request.ResearDTO;
import edu.hbut.entity.Airport;
import edu.hbut.entity.Flight;
import edu.hbut.service.HomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by dy on 2017/11/19.
 */
@Service
@Slf4j
public class HomeServiceImpl implements HomeService {

    private final HomeMapper homeDao;

    @Autowired
    public HomeServiceImpl(HomeMapper homeDao){this.homeDao=homeDao;}

    @Override
    public List<ResearDTO> search(HomeDTO homeDTO) {
        System.out.println("service 实现层");

        if(homeDao.queryinstan(homeDTO)!=null){   //判断数据库有没有对应方案，这是为了区别是不是转机情况的
            List<ResearDTO> researDTOList= homeDao.search(homeDTO); //给一个list用来记录每个备选方案对象
            System.out.println(researDTOList.size());
            return researDTOList;
        }
        return null;
    }
}
