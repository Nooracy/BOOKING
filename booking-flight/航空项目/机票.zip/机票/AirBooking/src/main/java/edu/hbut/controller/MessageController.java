package edu.hbut.controller;

import edu.hbut.dto.request.PlaneDTO;
import edu.hbut.dto.request.ResearDTO;
import edu.hbut.service.MessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/**
 * Created by dy on 2017/11/22.
 */
@Controller
@Slf4j
@RequestMapping("controller/message")
public class MessageController {

    @Autowired
    MessageService messageService;


    @RequestMapping("searchport")
    public String search(HttpSession session, Model model){
        int number=(int)session.getAttribute("number");
        ResearDTO researDTO=(ResearDTO)session.getAttribute("researDTO");
        String originPort=(String)session.getAttribute("originPort");
        String destination=(String)session.getAttribute("destination");
//        把它送到前端去
        model.addAttribute("researDTO",researDTO);
        model.addAttribute("originPort",originPort);
        model.addAttribute("destination",destination);

        PlaneDTO planeDTO = messageService.search(number);
        System.out.println(planeDTO.toString());
        model.addAttribute("planeDTO",planeDTO);

        return "message";

    }
}
