package edu.hbut.service;

import edu.hbut.dto.request.PassengerDTO;
import edu.hbut.entity.FlySeat;

import java.util.List;

/**
 * Created by dy on 2017/11/22.
 */
public interface SelectService {
    void insertPassenger(PassengerDTO passengerDTO);

    List<FlySeat> seatstate(Integer number);
}
