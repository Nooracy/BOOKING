/*
* @ 2017 11.20
*  这是result页面
*  功能：1.处理Result.jsp界面功能*/

function getRootContext(){
    var strPath = window.document.location.pathname;
    return strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
}

/**
 *获取上一个界面传的参数
 */
function GetArgs(params,paramName){
    var argsIndex = params.indexOf("?");
    var arg = params.substring(argsIndex+1);
    args = arg.split("&");
    var valArg = "";
    for(var i =0;i<args.length;i++){
        str = args[i];
        var arg = str.split("=");

        if(arg.length<=1) continue;
        if(arg[0] == paramName){
            valArg = arg[1];
        }
    }
    return valArg;
}
/*
$(function () {
    window.onload=function () {
        for(var i=0;i<)
        $("#plan").append(
        "<div class='position3' style=\"left:398px;top: 250px;width:1279px;height: 97px;  background:#FFFFFF;\">"+"</div>>"
        )
    }

})*/
