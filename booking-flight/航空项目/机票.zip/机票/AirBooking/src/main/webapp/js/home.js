/**
 * Created by dy on 2017/11/18.
 */

function getRootContext(){
    var strPath = window.document.location.pathname;
    return strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
}

