
function getRootContext(){
    var strPath = window.document.location.pathname;
    return strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
}

$(document).ready(function () {
    var urlRootContext=getRootContext();
    $.ajax({
        url:urlRootContext+"/select/seatstate",
        type:"POST",
        success:function (data) {
            alert(data[0].seatEmpty);
         /*var jsonDate=JSON.parse(data);*/
        for(var i=0;i<data.length;i++){
            if(data[i].seatEmpty=="1"){
                $("#"+(i+1)).attr("src","../../images/selectseat/8.png");
            }
        }
         }
    })

    $("img").click(function () {
        if($(this).attr("src")=="../../images/selectseat/7.png"){
            $(this).attr("src","../../images/selectseat/8.png");
        }
    })



})




