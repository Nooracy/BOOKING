/**
 * Created by dy on 2017/11/21.
 */

function getRootContext(){
    var strPath = window.document.location.pathname;
    return strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
}
 /*$(function () {
 window.onload=function () {
     var urlRootContext = getRootContext();
     $.ajax({
         type:"POST",
         url:urlRootContext+"/controller/message/searchport",
         success:function (data) {


         }
     })



  }
    })*/