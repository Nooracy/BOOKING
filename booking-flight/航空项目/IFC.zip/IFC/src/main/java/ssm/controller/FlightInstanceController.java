package ssm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ssm.dto.request.SeatsWithFlightinstanceId;
import ssm.dto.response.Response;
import ssm.pojo.Flightinstance;
import ssm.service.FlightInstanceService;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-21 9:16
 **/
@Controller
@RequestMapping("FlightInstanceController")
public class FlightInstanceController {
    @Autowired
    FlightInstanceService flightInstanceService;

    @PostMapping("AllFlightInstance")
    @ResponseBody
    public Response<List<Flightinstance>> AllFlightInstance(){
        List<Flightinstance> flightinstances = flightInstanceService.AllFlightInstance();
        return Response.getSuccessResponse(flightinstances);
    }

    @PostMapping("chooseSeat")
    @ResponseBody
    public Response<Boolean> chooseSeat(@RequestBody SeatsWithFlightinstanceId seatsWithFlightinstanceId){
        flightInstanceService.chooseSeat(seatsWithFlightinstanceId);
        return Response.getSuccessResponse(true);
    }


}
