package ssm.dto.request;

import java.util.Date;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-19 11:00
 **/
public class SelectFlightInstance {
    private Integer select_id;
    private Date departureDate;
    private String departureCity;
    private String arrivalCity;

    public Integer getSelect_id() {
        return select_id;
    }

    public void setSelect_id(Integer select_id) {
        this.select_id = select_id;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(Date departureDate) {
        this.departureDate = departureDate;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public void setDepartureCity(String departureCity) {
        this.departureCity = departureCity;
    }

    public String getArrivalCity() {
        return arrivalCity;
    }

    public void setArrivalCity(String arrivalCity) {
        this.arrivalCity = arrivalCity;
    }
}
