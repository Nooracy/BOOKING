package ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.mapper.OrderMapper;
import ssm.pojo.Order;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-24 18:42
 **/
@Service
public class OrderService {
    @Autowired
    OrderMapper orderMapper;

    public Integer add(Integer flightinstanceId) {
        Order order = new Order();
        order.setFlightinstanceIdFk(flightinstanceId);

        return orderMapper.insert(order);
    }
}
