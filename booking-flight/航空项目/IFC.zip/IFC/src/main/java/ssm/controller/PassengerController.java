package ssm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ssm.dto.response.Response;
import ssm.pojo.Passenger;
import ssm.service.PassengerService;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-23 17:22
 **/
@Controller
@RequestMapping("PassengerController")
public class PassengerController {
    @Autowired
    PassengerService passengerService;

    @RequestMapping("add")
    @ResponseBody
    public Response<List<Passenger>> addPassenger(@RequestBody List<Passenger> passengers){
        return Response.getSuccessResponse(passengerService.add(passengers));
    }
}
