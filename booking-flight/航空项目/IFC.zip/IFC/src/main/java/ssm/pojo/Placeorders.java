package ssm.pojo;

public class Placeorders {
    private Integer placeordersId;

    private Integer orderIdFk;

    private Integer passengerIdFk;

    private Integer passengerSeat;

    public Integer getPlaceordersId() {
        return placeordersId;
    }

    public void setPlaceordersId(Integer placeordersId) {
        this.placeordersId = placeordersId;
    }

    public Integer getOrderIdFk() {
        return orderIdFk;
    }

    public void setOrderIdFk(Integer orderIdFk) {
        this.orderIdFk = orderIdFk;
    }

    public Integer getPassengerIdFk() {
        return passengerIdFk;
    }

    public void setPassengerIdFk(Integer passengerIdFk) {
        this.passengerIdFk = passengerIdFk;
    }

    public Integer getPassengerSeat() {
        return passengerSeat;
    }

    public void setPassengerSeat(Integer passengerSeat) {
        this.passengerSeat = passengerSeat;
    }
}