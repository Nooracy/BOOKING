package ssm.dto.response;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-09-16 10:11
 **/
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Response<T> {
    private int statusCode;
    private String message;
    private T data;


    public static <T> Response<T> getSuccessResponse(T data){
        return new Response<T>(200,"OK",data);
    }
    public static <T> Response<T> getfailingResponse(T data){
        return new Response<T>(200,"NO",data);
    }

}

