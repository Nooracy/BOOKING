package ssm.pojo;

import java.util.Date;

public class Flight {
    private Integer flightId;

    private String flightName;

    private Integer departureairportid;

    private Integer arrivalairportid;

    private Date departuretime;

    private Date arrivaltime;

    private Double fare;

    private Integer airplaneIdFk;

    private Integer airlineIdFk;

    public Integer getFlightId() {
        return flightId;
    }

    public void setFlightId(Integer flightId) {
        this.flightId = flightId;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public Integer getDepartureairportid() {
        return departureairportid;
    }

    public void setDepartureairportid(Integer departureairportid) {
        this.departureairportid = departureairportid;
    }

    public Integer getArrivalairportid() {
        return arrivalairportid;
    }

    public void setArrivalairportid(Integer arrivalairportid) {
        this.arrivalairportid = arrivalairportid;
    }

    public Date getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(Date departuretime) {
        this.departuretime = departuretime;
    }

    public Date getArrivaltime() {
        return arrivaltime;
    }

    public void setArrivaltime(Date arrivaltime) {
        this.arrivaltime = arrivaltime;
    }

    public Double getFare() {
        return fare;
    }

    public void setFare(Double fare) {
        this.fare = fare;
    }

    public Integer getAirplaneIdFk() {
        return airplaneIdFk;
    }

    public void setAirplaneIdFk(Integer airplaneIdFk) {
        this.airplaneIdFk = airplaneIdFk;
    }

    public Integer getAirlineIdFk() {
        return airlineIdFk;
    }

    public void setAirlineIdFk(Integer airlineIdFk) {
        this.airlineIdFk = airlineIdFk;
    }
}