package ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import ssm.pojo.Flightinstance;
import ssm.pojo.FlightinstanceExample;

public interface FlightinstanceMapper {
    int countByExample(FlightinstanceExample example);

    int deleteByExample(FlightinstanceExample example);

    int deleteByPrimaryKey(Integer flightinstanceId);

    int insert(Flightinstance record);

    int insertSelective(Flightinstance record);

    List<Flightinstance> selectByExample(FlightinstanceExample example);

    Flightinstance selectByPrimaryKey(Integer flightinstanceId);

    int updateByExampleSelective(@Param("record") Flightinstance record, @Param("example") FlightinstanceExample example);

    int updateByExample(@Param("record") Flightinstance record, @Param("example") FlightinstanceExample example);

    int updateByPrimaryKeySelective(Flightinstance record);

    int updateByPrimaryKey(Flightinstance record);
}