package ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import ssm.pojo.Placeorders;
import ssm.pojo.PlaceordersExample;

public interface PlaceordersMapper {
    int countByExample(PlaceordersExample example);

    int deleteByExample(PlaceordersExample example);

    int deleteByPrimaryKey(Integer placeordersId);

    int insert(Placeorders record);

    int insertSelective(Placeorders record);

    List<Placeorders> selectByExample(PlaceordersExample example);

    Placeorders selectByPrimaryKey(Integer placeordersId);

    int updateByExampleSelective(@Param("record") Placeorders record, @Param("example") PlaceordersExample example);

    int updateByExample(@Param("record") Placeorders record, @Param("example") PlaceordersExample example);

    int updateByPrimaryKeySelective(Placeorders record);

    int updateByPrimaryKey(Placeorders record);
}