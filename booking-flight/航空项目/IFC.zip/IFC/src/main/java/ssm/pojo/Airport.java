package ssm.pojo;

public class Airport {
    private Integer airportId;

    private String airportName;

    private String airportCity;

    private String airportCountry;

    private Double connectiontime;

    public Integer getAirportId() {
        return airportId;
    }

    public void setAirportId(Integer airportId) {
        this.airportId = airportId;
    }

    public String getAirportName() {
        return airportName;
    }

    public void setAirportName(String airportName) {
        this.airportName = airportName;
    }

    public String getAirportCity() {
        return airportCity;
    }

    public void setAirportCity(String airportCity) {
        this.airportCity = airportCity;
    }

    public String getAirportCountry() {
        return airportCountry;
    }

    public void setAirportCountry(String airportCountry) {
        this.airportCountry = airportCountry;
    }

    public Double getConnectiontime() {
        return connectiontime;
    }

    public void setConnectiontime(Double connectiontime) {
        this.connectiontime = connectiontime;
    }
}