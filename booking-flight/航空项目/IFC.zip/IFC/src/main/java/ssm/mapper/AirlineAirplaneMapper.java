package ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import ssm.pojo.AirlineAirplane;
import ssm.pojo.AirlineAirplaneExample;

public interface AirlineAirplaneMapper {
    int countByExample(AirlineAirplaneExample example);

    int deleteByExample(AirlineAirplaneExample example);

    int deleteByPrimaryKey(Integer airlineAirplaneId);

    int insert(AirlineAirplane record);

    int insertSelective(AirlineAirplane record);

    List<AirlineAirplane> selectByExample(AirlineAirplaneExample example);

    AirlineAirplane selectByPrimaryKey(Integer airlineAirplaneId);

    int updateByExampleSelective(@Param("record") AirlineAirplane record, @Param("example") AirlineAirplaneExample example);

    int updateByExample(@Param("record") AirlineAirplane record, @Param("example") AirlineAirplaneExample example);

    int updateByPrimaryKeySelective(AirlineAirplane record);

    int updateByPrimaryKey(AirlineAirplane record);
}