package ssm.pojo;

public class AirportFlight {
    private Integer airportFlightId;

    private Integer airportIdFk;

    private Integer flightIdFk;

    public Integer getAirportFlightId() {
        return airportFlightId;
    }

    public void setAirportFlightId(Integer airportFlightId) {
        this.airportFlightId = airportFlightId;
    }

    public Integer getAirportIdFk() {
        return airportIdFk;
    }

    public void setAirportIdFk(Integer airportIdFk) {
        this.airportIdFk = airportIdFk;
    }

    public Integer getFlightIdFk() {
        return flightIdFk;
    }

    public void setFlightIdFk(Integer flightIdFk) {
        this.flightIdFk = flightIdFk;
    }
}