package ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import ssm.pojo.AirportFlight;
import ssm.pojo.AirportFlightExample;

public interface AirportFlightMapper {
    int countByExample(AirportFlightExample example);

    int deleteByExample(AirportFlightExample example);

    int deleteByPrimaryKey(Integer airportFlightId);

    int insert(AirportFlight record);

    int insertSelective(AirportFlight record);

    List<AirportFlight> selectByExample(AirportFlightExample example);

    AirportFlight selectByPrimaryKey(Integer airportFlightId);

    int updateByExampleSelective(@Param("record") AirportFlight record, @Param("example") AirportFlightExample example);

    int updateByExample(@Param("record") AirportFlight record, @Param("example") AirportFlightExample example);

    int updateByPrimaryKeySelective(AirportFlight record);

    int updateByPrimaryKey(AirportFlight record);
}