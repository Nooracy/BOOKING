package ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.dto.response.SpecificFlightInformation;
import ssm.mapper.*;
import ssm.pojo.*;

import java.util.ArrayList;
import java.util.List;

@Service
public class EnquiryFlightService {
    @Autowired
    AirlineMapper airlineMapper;
    @Autowired
    AirplaneMapper airplaneMapper;
    @Autowired
    AirportMapper airportMapper;
    @Autowired
    FlightMapper flightMapper;
    @Autowired
    FlightinstanceMapper flightinstanceMapper;

    public SpecificFlightInformation enquiryFlight( ){
        //查询出所有的航空公司
        List<Airline> airlines = new ArrayList<>();
        AirlineExample airlineExample = new AirlineExample();
        airlines = airlineMapper.selectByExample(airlineExample);

        //查询出所有的飞机
        List<Airplane> airplanes = new ArrayList<>();
        AirplaneExample airplaneExample = new AirplaneExample();
        airplanes = airplaneMapper.selectByExample(airplaneExample);

        //查询出所有的机场
        List<Airport> airports = new ArrayList<>();
        AirportExample airportExample = new AirportExample();
        airports = airportMapper.selectByExample(airportExample);

        //查询出所有的航班
        List<Flight> flights = new ArrayList<>();
        FlightExample flightExample = new FlightExample();
        flights = flightMapper.selectByExample(flightExample);

        //查出所有的航班实例
        List<Flightinstance> flightinstances = new ArrayList<>();
        FlightinstanceExample flightinstanceExample = new FlightinstanceExample();
        flightinstances = flightinstanceMapper.selectByExample(flightinstanceExample);

        SpecificFlightInformation specificFlightInformation = new SpecificFlightInformation();
        specificFlightInformation.setAirlines(airlines);
        specificFlightInformation.setAirplanes(airplanes);
        specificFlightInformation.setAirports(airports);
        specificFlightInformation.setFlights(flights);
        specificFlightInformation.setFlightinstances(flightinstances);

        return specificFlightInformation;
        //这里应该返回一组航班实例，里面发机场，到达有出发城市，出城市，到达机场(airport)，航班时间，航班名称，飞机机型(airplane)，飞行日期(flightInstance)，价钱(flight)，航空公司折扣信息（airline），座位情况
    }
}
