package ssm.pojo;

public class Passenger {
    private Integer passengerId;

    private String passengerName;

    private String passengerIdnumber;

    private Integer phonenumber;

    private String passportnumber;

    private Integer account;

    public Integer getPassengerId() {
        return passengerId;
    }

    public void setPassengerId(Integer passengerId) {
        this.passengerId = passengerId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getPassengerIdnumber() {
        return passengerIdnumber;
    }

    public void setPassengerIdnumber(String passengerIdnumber) {
        this.passengerIdnumber = passengerIdnumber;
    }

    public Integer getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(Integer phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getPassportnumber() {
        return passportnumber;
    }

    public void setPassportnumber(String passportnumber) {
        this.passportnumber = passportnumber;
    }

    public Integer getAccount() {
        return account;
    }

    public void setAccount(Integer account) {
        this.account = account;
    }
}