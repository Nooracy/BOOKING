package ssm.dto.request;

import lombok.Data;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-24 16:15
 **/
public class SeatsWithFlightinstanceId {
    private String seats;
    private Integer flightinstanceId;

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public Integer getFlightinstanceId() {
        return flightinstanceId;
    }

    public void setFlightinstanceId(Integer flightinstanceId) {
        this.flightinstanceId = flightinstanceId;
    }
}
