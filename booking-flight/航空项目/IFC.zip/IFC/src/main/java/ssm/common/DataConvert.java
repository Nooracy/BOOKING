package ssm.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Frank on 2017/6/27.
 */
public class DataConvert implements org.springframework.core.convert.converter.Converter<String,Date> {

    @Override
    public Date convert(String source) {
        String date=(String)source;
        try {
            SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date d=format.parse(date);
            System.out.println("转换后的结果"+d);
            return d;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
