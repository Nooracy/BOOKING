package ssm.pojo;

public class Airline {
    private Integer airlineId;

    private String airlineName;

    private Double ownDiscount;

    public Integer getAirlineId() {
        return airlineId;
    }

    public void setAirlineId(Integer airlineId) {
        this.airlineId = airlineId;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public Double getOwnDiscount() {
        return ownDiscount;
    }

    public void setOwnDiscount(Double ownDiscount) {
        this.ownDiscount = ownDiscount;
    }
}