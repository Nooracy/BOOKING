package ssm.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class FlightExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FlightExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCTime(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Time(value.getTime()), property);
        }

        protected void addCriterionForJDBCTime(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Time> timeList = new ArrayList<java.sql.Time>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                timeList.add(new java.sql.Time(iter.next().getTime()));
            }
            addCriterion(condition, timeList, property);
        }

        protected void addCriterionForJDBCTime(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);
        }

        public Criteria andFlightIdIsNull() {
            addCriterion("flight_id is null");
            return (Criteria) this;
        }

        public Criteria andFlightIdIsNotNull() {
            addCriterion("flight_id is not null");
            return (Criteria) this;
        }

        public Criteria andFlightIdEqualTo(Integer value) {
            addCriterion("flight_id =", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdNotEqualTo(Integer value) {
            addCriterion("flight_id <>", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdGreaterThan(Integer value) {
            addCriterion("flight_id >", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("flight_id >=", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdLessThan(Integer value) {
            addCriterion("flight_id <", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdLessThanOrEqualTo(Integer value) {
            addCriterion("flight_id <=", value, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdIn(List<Integer> values) {
            addCriterion("flight_id in", values, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdNotIn(List<Integer> values) {
            addCriterion("flight_id not in", values, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdBetween(Integer value1, Integer value2) {
            addCriterion("flight_id between", value1, value2, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightIdNotBetween(Integer value1, Integer value2) {
            addCriterion("flight_id not between", value1, value2, "flightId");
            return (Criteria) this;
        }

        public Criteria andFlightNameIsNull() {
            addCriterion("flight_name is null");
            return (Criteria) this;
        }

        public Criteria andFlightNameIsNotNull() {
            addCriterion("flight_name is not null");
            return (Criteria) this;
        }

        public Criteria andFlightNameEqualTo(String value) {
            addCriterion("flight_name =", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameNotEqualTo(String value) {
            addCriterion("flight_name <>", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameGreaterThan(String value) {
            addCriterion("flight_name >", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameGreaterThanOrEqualTo(String value) {
            addCriterion("flight_name >=", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameLessThan(String value) {
            addCriterion("flight_name <", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameLessThanOrEqualTo(String value) {
            addCriterion("flight_name <=", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameLike(String value) {
            addCriterion("flight_name like", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameNotLike(String value) {
            addCriterion("flight_name not like", value, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameIn(List<String> values) {
            addCriterion("flight_name in", values, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameNotIn(List<String> values) {
            addCriterion("flight_name not in", values, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameBetween(String value1, String value2) {
            addCriterion("flight_name between", value1, value2, "flightName");
            return (Criteria) this;
        }

        public Criteria andFlightNameNotBetween(String value1, String value2) {
            addCriterion("flight_name not between", value1, value2, "flightName");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidIsNull() {
            addCriterion("departureAirportId is null");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidIsNotNull() {
            addCriterion("departureAirportId is not null");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidEqualTo(Integer value) {
            addCriterion("departureAirportId =", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidNotEqualTo(Integer value) {
            addCriterion("departureAirportId <>", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidGreaterThan(Integer value) {
            addCriterion("departureAirportId >", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidGreaterThanOrEqualTo(Integer value) {
            addCriterion("departureAirportId >=", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidLessThan(Integer value) {
            addCriterion("departureAirportId <", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidLessThanOrEqualTo(Integer value) {
            addCriterion("departureAirportId <=", value, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidIn(List<Integer> values) {
            addCriterion("departureAirportId in", values, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidNotIn(List<Integer> values) {
            addCriterion("departureAirportId not in", values, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidBetween(Integer value1, Integer value2) {
            addCriterion("departureAirportId between", value1, value2, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andDepartureairportidNotBetween(Integer value1, Integer value2) {
            addCriterion("departureAirportId not between", value1, value2, "departureairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidIsNull() {
            addCriterion("arrivalAirportId is null");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidIsNotNull() {
            addCriterion("arrivalAirportId is not null");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidEqualTo(Integer value) {
            addCriterion("arrivalAirportId =", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidNotEqualTo(Integer value) {
            addCriterion("arrivalAirportId <>", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidGreaterThan(Integer value) {
            addCriterion("arrivalAirportId >", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidGreaterThanOrEqualTo(Integer value) {
            addCriterion("arrivalAirportId >=", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidLessThan(Integer value) {
            addCriterion("arrivalAirportId <", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidLessThanOrEqualTo(Integer value) {
            addCriterion("arrivalAirportId <=", value, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidIn(List<Integer> values) {
            addCriterion("arrivalAirportId in", values, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidNotIn(List<Integer> values) {
            addCriterion("arrivalAirportId not in", values, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidBetween(Integer value1, Integer value2) {
            addCriterion("arrivalAirportId between", value1, value2, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andArrivalairportidNotBetween(Integer value1, Integer value2) {
            addCriterion("arrivalAirportId not between", value1, value2, "arrivalairportid");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeIsNull() {
            addCriterion("departureTime is null");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeIsNotNull() {
            addCriterion("departureTime is not null");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeEqualTo(Date value) {
            addCriterionForJDBCTime("departureTime =", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeNotEqualTo(Date value) {
            addCriterionForJDBCTime("departureTime <>", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeGreaterThan(Date value) {
            addCriterionForJDBCTime("departureTime >", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("departureTime >=", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeLessThan(Date value) {
            addCriterionForJDBCTime("departureTime <", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("departureTime <=", value, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeIn(List<Date> values) {
            addCriterionForJDBCTime("departureTime in", values, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeNotIn(List<Date> values) {
            addCriterionForJDBCTime("departureTime not in", values, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("departureTime between", value1, value2, "departuretime");
            return (Criteria) this;
        }

        public Criteria andDeparturetimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("departureTime not between", value1, value2, "departuretime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeIsNull() {
            addCriterion("arrivalTime is null");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeIsNotNull() {
            addCriterion("arrivalTime is not null");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeEqualTo(Date value) {
            addCriterionForJDBCTime("arrivalTime =", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeNotEqualTo(Date value) {
            addCriterionForJDBCTime("arrivalTime <>", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeGreaterThan(Date value) {
            addCriterionForJDBCTime("arrivalTime >", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("arrivalTime >=", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeLessThan(Date value) {
            addCriterionForJDBCTime("arrivalTime <", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("arrivalTime <=", value, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeIn(List<Date> values) {
            addCriterionForJDBCTime("arrivalTime in", values, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeNotIn(List<Date> values) {
            addCriterionForJDBCTime("arrivalTime not in", values, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("arrivalTime between", value1, value2, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andArrivaltimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("arrivalTime not between", value1, value2, "arrivaltime");
            return (Criteria) this;
        }

        public Criteria andFareIsNull() {
            addCriterion("fare is null");
            return (Criteria) this;
        }

        public Criteria andFareIsNotNull() {
            addCriterion("fare is not null");
            return (Criteria) this;
        }

        public Criteria andFareEqualTo(Double value) {
            addCriterion("fare =", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareNotEqualTo(Double value) {
            addCriterion("fare <>", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareGreaterThan(Double value) {
            addCriterion("fare >", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareGreaterThanOrEqualTo(Double value) {
            addCriterion("fare >=", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareLessThan(Double value) {
            addCriterion("fare <", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareLessThanOrEqualTo(Double value) {
            addCriterion("fare <=", value, "fare");
            return (Criteria) this;
        }

        public Criteria andFareIn(List<Double> values) {
            addCriterion("fare in", values, "fare");
            return (Criteria) this;
        }

        public Criteria andFareNotIn(List<Double> values) {
            addCriterion("fare not in", values, "fare");
            return (Criteria) this;
        }

        public Criteria andFareBetween(Double value1, Double value2) {
            addCriterion("fare between", value1, value2, "fare");
            return (Criteria) this;
        }

        public Criteria andFareNotBetween(Double value1, Double value2) {
            addCriterion("fare not between", value1, value2, "fare");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkIsNull() {
            addCriterion("airplane_id_fk is null");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkIsNotNull() {
            addCriterion("airplane_id_fk is not null");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkEqualTo(Integer value) {
            addCriterion("airplane_id_fk =", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkNotEqualTo(Integer value) {
            addCriterion("airplane_id_fk <>", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkGreaterThan(Integer value) {
            addCriterion("airplane_id_fk >", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkGreaterThanOrEqualTo(Integer value) {
            addCriterion("airplane_id_fk >=", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkLessThan(Integer value) {
            addCriterion("airplane_id_fk <", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkLessThanOrEqualTo(Integer value) {
            addCriterion("airplane_id_fk <=", value, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkIn(List<Integer> values) {
            addCriterion("airplane_id_fk in", values, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkNotIn(List<Integer> values) {
            addCriterion("airplane_id_fk not in", values, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkBetween(Integer value1, Integer value2) {
            addCriterion("airplane_id_fk between", value1, value2, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirplaneIdFkNotBetween(Integer value1, Integer value2) {
            addCriterion("airplane_id_fk not between", value1, value2, "airplaneIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkIsNull() {
            addCriterion("airline_id_fk is null");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkIsNotNull() {
            addCriterion("airline_id_fk is not null");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkEqualTo(Integer value) {
            addCriterion("airline_id_fk =", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkNotEqualTo(Integer value) {
            addCriterion("airline_id_fk <>", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkGreaterThan(Integer value) {
            addCriterion("airline_id_fk >", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkGreaterThanOrEqualTo(Integer value) {
            addCriterion("airline_id_fk >=", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkLessThan(Integer value) {
            addCriterion("airline_id_fk <", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkLessThanOrEqualTo(Integer value) {
            addCriterion("airline_id_fk <=", value, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkIn(List<Integer> values) {
            addCriterion("airline_id_fk in", values, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkNotIn(List<Integer> values) {
            addCriterion("airline_id_fk not in", values, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkBetween(Integer value1, Integer value2) {
            addCriterion("airline_id_fk between", value1, value2, "airlineIdFk");
            return (Criteria) this;
        }

        public Criteria andAirlineIdFkNotBetween(Integer value1, Integer value2) {
            addCriterion("airline_id_fk not between", value1, value2, "airlineIdFk");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}