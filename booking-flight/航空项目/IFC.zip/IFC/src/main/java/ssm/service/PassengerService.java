package ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.mapper.PassengerMapper;
import ssm.pojo.Passenger;
import ssm.pojo.PassengerExample;

import java.util.ArrayList;
import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-23 17:23
 **/
@Service
public class PassengerService {
    @Autowired
    PassengerMapper passengerMapper;

    public List<Passenger> add(List<Passenger> passengers) {
        List<Passenger> returnPassengers = new ArrayList<>();

        for (Passenger s:passengers) {
            passengerMapper.insert(s);

            PassengerExample passengerExample = new PassengerExample();
            PassengerExample.Criteria criteria = passengerExample.createCriteria();
            criteria.andPassengerIdnumberEqualTo(s.getPassengerIdnumber());
            returnPassengers.add(passengerMapper.selectByExample(passengerExample).get(0));
        }

        return returnPassengers;
    }
}
