package ssm.pojo;

import java.util.Date;

public class Flightinstance {
    private Integer flightinstanceId;

    private Date date;

    private Integer flightIdFk;

    private String seat;

    public Integer getFlightinstanceId() {
        return flightinstanceId;
    }

    public void setFlightinstanceId(Integer flightinstanceId) {
        this.flightinstanceId = flightinstanceId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getFlightIdFk() {
        return flightIdFk;
    }

    public void setFlightIdFk(Integer flightIdFk) {
        this.flightIdFk = flightIdFk;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }
}