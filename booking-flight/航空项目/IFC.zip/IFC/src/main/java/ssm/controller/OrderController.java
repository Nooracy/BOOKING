package ssm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ssm.dto.response.Response;
import ssm.pojo.Order;
import ssm.service.OrderService;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-24 18:41
 **/
@Controller
@RequestMapping("OrderController")
public class OrderController {
    @Autowired
    OrderService orderService;

    @PostMapping("add")
    @ResponseBody
    public Response<Integer> add(@RequestBody Integer flightinstanceId){
        return Response.getSuccessResponse(orderService.add(flightinstanceId));
    }

}
