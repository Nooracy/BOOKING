package ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import ssm.pojo.Airplane;
import ssm.pojo.AirplaneExample;

public interface AirplaneMapper {
    int countByExample(AirplaneExample example);

    int deleteByExample(AirplaneExample example);

    int deleteByPrimaryKey(Integer airplaneId);

    int insert(Airplane record);

    int insertSelective(Airplane record);

    List<Airplane> selectByExample(AirplaneExample example);

    Airplane selectByPrimaryKey(Integer airplaneId);

    int updateByExampleSelective(@Param("record") Airplane record, @Param("example") AirplaneExample example);

    int updateByExample(@Param("record") Airplane record, @Param("example") AirplaneExample example);

    int updateByPrimaryKeySelective(Airplane record);

    int updateByPrimaryKey(Airplane record);
}