package ssm.dto.response;

import ssm.pojo.Airport;
import ssm.pojo.Flightinstance;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-19 10:58
 **/
public class GraphPath {
    private List<Flightinstance> flightinstances;
    private List<Airport> airports;

    public List<Flightinstance> getFlightinstances() {
        return flightinstances;
    }

    public void setFlightinstances(List<Flightinstance> flightinstances) {
        this.flightinstances = flightinstances;
    }

    public List<Airport> getAirports() {
        return airports;
    }

    public void setAirports(List<Airport> airports) {
        this.airports = airports;
    }
}
