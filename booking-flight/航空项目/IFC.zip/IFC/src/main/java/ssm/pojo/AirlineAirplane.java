package ssm.pojo;

public class AirlineAirplane {
    private Integer airlineAirplaneId;

    private Integer airlineIdFk;

    private Integer airplaneIdFk;

    public Integer getAirlineAirplaneId() {
        return airlineAirplaneId;
    }

    public void setAirlineAirplaneId(Integer airlineAirplaneId) {
        this.airlineAirplaneId = airlineAirplaneId;
    }

    public Integer getAirlineIdFk() {
        return airlineIdFk;
    }

    public void setAirlineIdFk(Integer airlineIdFk) {
        this.airlineIdFk = airlineIdFk;
    }

    public Integer getAirplaneIdFk() {
        return airplaneIdFk;
    }

    public void setAirplaneIdFk(Integer airplaneIdFk) {
        this.airplaneIdFk = airplaneIdFk;
    }
}