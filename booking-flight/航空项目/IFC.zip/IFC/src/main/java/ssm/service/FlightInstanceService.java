package ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.dto.request.SeatsWithFlightinstanceId;
import ssm.mapper.FlightinstanceMapper;
import ssm.pojo.Flightinstance;
import ssm.pojo.FlightinstanceExample;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-21 9:16
 **/
@Service
public class FlightInstanceService {
    @Autowired
    FlightinstanceMapper flightinstanceMapper;

    public List<Flightinstance> AllFlightInstance() {
        FlightinstanceExample flightinstanceExample = new FlightinstanceExample();
        List<Flightinstance> flightinstances = flightinstanceMapper.selectByExample(flightinstanceExample);
        return flightinstances;
    }

    public void chooseSeat(SeatsWithFlightinstanceId seatsWithFlightinstanceId) {
        Flightinstance flightinstance = flightinstanceMapper.selectByPrimaryKey(seatsWithFlightinstanceId.getFlightinstanceId());
        flightinstance.setSeat(seatsWithFlightinstanceId.getSeats());

        flightinstanceMapper.updateByPrimaryKey(flightinstance);
    }
}
