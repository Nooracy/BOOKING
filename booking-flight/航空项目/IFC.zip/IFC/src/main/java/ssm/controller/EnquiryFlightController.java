package ssm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ssm.dto.response.Response;
import ssm.dto.response.SpecificFlightInformation;
import ssm.service.EnquiryFlightService;

@Controller
public class EnquiryFlightController {
    @Autowired
    EnquiryFlightService enquiryFlightService;
    @RequestMapping("/enquiryFlight.action")
    @ResponseBody
    public Response<SpecificFlightInformation> enquiryFlight(){
        SpecificFlightInformation specificFlightInformation = enquiryFlightService.enquiryFlight();

        return Response.getSuccessResponse(specificFlightInformation);//返回一个查询航班结果给前台ajax
    }
}
