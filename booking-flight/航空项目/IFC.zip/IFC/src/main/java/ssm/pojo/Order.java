package ssm.pojo;

public class Order {
    private Integer orderId;

    private Integer flightinstanceIdFk;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getFlightinstanceIdFk() {
        return flightinstanceIdFk;
    }

    public void setFlightinstanceIdFk(Integer flightinstanceIdFk) {
        this.flightinstanceIdFk = flightinstanceIdFk;
    }
}