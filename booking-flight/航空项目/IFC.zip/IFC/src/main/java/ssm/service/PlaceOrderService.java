package ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.mapper.PlaceordersMapper;
import ssm.pojo.Placeorders;

/**
 * ${DESCRIPTION}
 *
 * @author gpf
 * @create 2017-11-24 19:10
 **/
@Service
public class PlaceOrderService {
    @Autowired
    PlaceordersMapper placeordersMapper;

    public Boolean add(Placeorders placeorders) {
        placeordersMapper.insert(placeorders);
        return true;
    }
}
