package ssm.dto.response;

import lombok.Data;
import org.apache.commons.fileupload.util.LimitedInputStream;
import ssm.pojo.*;

import java.util.List;

@Data
public class SpecificFlightInformation {
    private List<Airline> airlines;
    private List<Airplane> airplanes;
    private List<Airport> airports;
    private List<Flight> flights;
    private List<Flightinstance> flightinstances;

    public List<Airline> getAirlines() {
        return airlines;
    }

    public void setAirlines(List<Airline> airlines) {
        this.airlines = airlines;
    }

    public List<Airplane> getAirplanes() {
        return airplanes;
    }

    public void setAirplanes(List<Airplane> airplanes) {
        this.airplanes = airplanes;
    }

    public List<Airport> getAirports() {
        return airports;
    }

    public void setAirports(List<Airport> airports) {
        this.airports = airports;
    }

    public List<Flight> getFlights() {
        return flights;
    }

    public void setFlights(List<Flight> flights) {
        this.flights = flights;
    }

    public List<Flightinstance> getFlightinstances() {
        return flightinstances;
    }

    public void setFlightinstances(List<Flightinstance> flightinstances) {
        this.flightinstances = flightinstances;
    }
}
