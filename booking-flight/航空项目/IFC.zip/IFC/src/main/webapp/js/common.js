/**
 * 字符串替换特定字符
 * @param source
 * @param pos
 * @param newChar
 * @returns {*}
 */
function replaceChat(source,pos,newChar){
    if(pos<0||pos>=source.length||source.length==0){
        return "invalid parameters...";
    }
    var iBeginPos= 0, iEndPos=source.length;
    var sFrontPart=source.substr(iBeginPos,pos);
    var sTailPart=source.substr(pos+1,source.length);
    var sRet=sFrontPart+newChar+sTailPart;
    return sRet;
}

/**
 *获取上一个界面传的参数
 */
function GetArgs(params,paramName){
    var argsIndex = params.indexOf("?");
    var arg = params.substring(argsIndex+1);
    args = arg.split("&");
    var valArg = "";
    for(var i =0;i<args.length;i++){
        str = args[i];
        var arg = str.split("=");

        if(arg.length<=1) continue;
        if(arg[0] == paramName){
            valArg = arg[1];
        }
    }
    return valArg;
}

/**
 * 将后台时间转换为前台的时间展示
 * @param str
 * @returns {string}
 */
function getMyDate(str){
    var oDate = new Date(str),
        oYear = oDate.getFullYear(),
        oMonth = oDate.getMonth()+1,
        oDay = oDate.getDate(),
        oHour = oDate.getHours(),
        oMin = oDate.getMinutes(),
        oSen = oDate.getSeconds(),
        oTime = oYear +'-'+ getzf(oMonth) +'-'+ getzf(oDay) +' '+ getzf(oHour) +':'+ getzf(oMin) +':'+getzf(oSen);//最后拼接时间
    return oTime;
};
//补0操作
function getzf(num){
    if(parseInt(num) < 10){
        num = '0'+num;
    }
    return num;
}
