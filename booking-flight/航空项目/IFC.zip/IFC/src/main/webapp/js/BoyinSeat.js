//服务器数据(初始为空)
var AllData;
//当前座位列表
var currentSeats;
//已选座位列表
var checkSeatList = [];
//乘机人数
var numberOfPassengers = 3;
//选中的航班
var flightinstanceId = 2;
//后台查出来乘机人列表（带id）
var Passengers;


/**
 * 打印空客的座位
 * @constructor
 */
function ShowBoyinSeat() {
    var left = 410;
    var top = 590;
    //头等舱座位(1-3排)
    for (var line = 0; line < 2; line++) {
        for (var row = 1; row < 5; row++) {
            if (row<3) {
                //第一排-1
                $("#Kongke").append(
                    "<input id=\"seat"+(row+4*line)+"\" type=\"button\" class=\"primarySeatOfKongke\" style=\"left: "+(460+40*line)+"px;top: "+(614-24*row)+"px;\"/>"
                )
            } else if (row >= 3 && row < 5){
                //第一排-2
                $("#Kongke").append(
                    "<input id=\"seat"+(row+4*line)+"\" type=\"button\" class=\"primarySeatOfKongke\" style=\"left: "+(460+40*line)+"px;top: "+(614-10-24*row)+"px;\"/>"
                )
            }

        }
    }

    //商务舱座位(11-17排)
    for (var line = 0; line < 7; line++) {
        for (var row = 1; row < 7; row++) {
            if (row<4) {
                $("#Kongke").append(
                    "<input id=\"seat"+(8+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(560+31.5*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                )
            } else if (row >= 4 && row < 7){
                $("#Kongke").append(
                    "<input id=\"seat"+(8+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(560+31.5*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                )
            }
        }

    }

    //商务舱座位(18-30排)
    for (var line = 0; line < 3; line++) {
        for (var row = 1; row < 7; row++) {
            if (row<4) {
                $("#Kongke").append(
                    "<input id=\"seat"+(50+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+31*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                )
            } else if (row >= 4 && row < 7){
                $("#Kongke").append(
                    "<input id=\"seat"+(50+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+31*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                )
            }
        }
    }
    for (var line = 0; line < 3; line++) {
        for (var row = 1; row < 7; row++) {
            if (row<4) {
                $("#Kongke").append(
                    "<input id=\"seat"+(50+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+31*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                )
            } else if (row >= 4 && row < 7){
                $("#Kongke").append(
                    "<input id=\"seat"+(50+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+31*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                )
            }
        }
    }
    for (var line = 0; line < 3; line++) {
        for (var row = 1; row < 7; row++) {
            if (row<4) {
                $("#Kongke").append(
                    "<input id=\"seat"+(50+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+31*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                )
            } else if (row >= 4 && row < 7){
                $("#Kongke").append(
                    "<input id=\"seat"+(50+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+31*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                )
            }
        }
    }
    for (var line = 0; line < 4; line++) {
        if (line<3){
            for (var row = 1; row < 7; row++) {
                if (row<4) {
                    $("#Kongke").append(
                        "<input id=\"seat"+(50+18+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+(31*3-2)+31*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                    )
                } else if (row >= 4 && row < 7){
                    $("#Kongke").append(
                        "<input id=\"seat"+(50+18+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+(31*3-2)+31*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                    )
                }
            }
        }else {
            for (var row = 1; row < 7; row++) {
                if (row<4) {
                    $("#Kongke").append(
                        "<input id=\"seat"+(50+18+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+(31*3-2)+2+31*line)+"px;top: "+(607+1-14*row)+"px;\"/>"
                    )
                } else if (row >= 4 && row < 7){
                    $("#Kongke").append(
                        "<input id=\"seat"+(50+18+18+18+row+6*line)+"\" type=\"button\" class=\"normalSeatOfKongke\" style=\"left: "+(780.5+3+(31*3-2)+(31*3-2)+(31*3-2)+2+31*line)+"px;top: "+(607-1-12-14*row)+"px;\"/>"
                    )
                }
            }
        }

    }
}

/**
 * 更新空客座位信息
 */
function repeatKongkeSeat(seat) {
	for (var i = 0; i < seat.length; i++){
		var flag = seat.charAt(i);
		if (flag == 'B'){
            $("#seat"+(i+1)).css({"background": "darkgray"})
            $("#seat"+(i+1)).attr("disabled", true);
        }
	}
}

/**
 * 打印出乘机人输入列表
 */
function ShowPassengers() {
    for (var i = 0; i < numberOfPassengers; i++){
        $("#inputPassengers").append(
            " <div>乘客"+(i+1)+"：&nbsp;&nbsp;姓名：<input id=\"name"+(i+1)+"\" onblur=\"checkBlur('姓名',this.value,"+(i+1)+")\" type=\"text\">身份证：<input id=\"ID"+(i+1)+"\" onblur=\"checkBlur('身份证', this.value, "+(i+1)+")\" type=\"text\">护照：<input id=\"PassPort"+(i+1)+"\"  onblur=\"checkBlur('护照', this.value, "+(i+1)+")\"    type=\"text\">手机号：<input id=\"Phone"+(i+1)+"\"   onblur=\"checkBlur('手机号', this.value, "+(i+1)+")\" type=\"text\"><label id=\"notice"+(i+1)+"\"></label></div>"
        )
    }
}



/**
 * 提交座位信息到后台,生成订单
 */
function getcheckSeatList() {

    /**
     * 公共变量orderId
     */
    var orderId;

    /**
     * 0、获取乘机人信息,提交到后台
     */
    var list = [];
    for (var i = 0; i < numberOfPassengers; i++){
        var passenger = {};
        passenger.passengerName = $("#name"+(i+1)).val();
        passenger.passengerIdnumber = $("#ID"+(i+1)).val();
        passenger.passportnumber = $("#PassPort"+(i+1)).val();
        passenger.phonenumber = $("#Phone"+(i+1)).val();

        list.push(passenger)
    }
    console.log(list);

    $.ajax({
        type:"POST",
        url:"/PassengerController/add",
        data:JSON.stringify(list),
        contentType:"application/json",
        dataType:"json",
        success:function (data) {
            console.log(data);
            Passengers = data.data;

            /**
             * 1、提交座位信息到后台
             */
            //更新成选好座位后的座位列表
            for (var i = 0; i < checkSeatList.length; i++){
                currentSeats = replaceChat(currentSeats,checkSeatList[i]-1,'B');
            }

            var seatsWithFlightinstanceId = {};
            seatsWithFlightinstanceId.seats = currentSeats;
            seatsWithFlightinstanceId.flightinstanceId = flightinstanceId;

            $.ajax({
                type:"POST",
                url:"/FlightInstanceController/chooseSeat",
                data:JSON.stringify(seatsWithFlightinstanceId),
                contentType:"application/json",
                dataType:"json",
                success:function (data) {
                    console.log(data);

                    /**
                     * 2、生成订单order的记录
                     */
                    $.ajax({
                        type:"POST",
                        url:"/OrderController/add",
                        data:JSON.stringify(flightinstanceId),
                        contentType:"application/json",
                        dataType:"json",
                        success:function (data) {
                            console.log(data);
                            orderId = data.data;

                            /**
                             * 3、生成中间表placeorder的记录
                             */
                            for (var i = 0; i < checkSeatList.length; i++){
                                var placeOrder = {};
                                placeOrder.orderIdFk = orderId;
                                placeOrder.passengerIdFk = Passengers[i].passengerId;
                                placeOrder.passengerSeat = checkSeatList[i];
                                console.log(placeOrder);

                                $.ajax({
                                    type:"POST",
                                    url:"/PlaceOrderController/add",
                                    data:JSON.stringify(placeOrder),
                                    contentType:"application/json",
                                    dataType:"json",
                                    success:function (data) {
                                        console.log(data);
                                        /**
                                         * 查询完一次之后，全局变量要清空
                                         */
                                        //服务器数据(初始为空)
                                        var AllData = null;
                                        //当前座位列表
                                        var currentSeats = null;
                                        //已选座位列表
                                        var checkSeatList = [];
                                        //乘机人数
                                        var numberOfPassengers = 3;
                                        //选中的航班
                                        var flightinstanceId = 1;
                                        //后台查出来乘机人列表（带id）
                                        var Passengers = null;
                                    }
                                });
                            }
                        }
                    });
                }
            });

        }
    });









}


/**
 * 验证输入乘机人情况
 */
function checkBlur(str,value,id) {
    if (value == ""){
        $("#notice"+id).html("");
        $("#notice"+id).append("<font color='red'>"+str+"不能为空！</font>");
    }else {
        $("#notice"+id).html("");

    }

    // $("#submitBtn").attr("disabled", true);
    // $("#submitBtn").attr("disabled", false);
}

$(function(){



    //打印出座位按钮
     ShowBoyinSeat();
    //打印出乘机人输入列表
    ShowPassengers();

    $.ajax({
        type:"POST",
        url:"/enquiryFlight.action",
        // data:JSON.stringify(data),
        // contentType:"application/json",
        dataType:"json",
        success:function (data) {
            console.log(data);
            AllData = data.data;

            $.each(data.data.flightinstances,function (i,item) {
				if (item.flightinstanceId == flightinstanceId){
				    currentSeats = item.seat;
					repeatKongkeSeat(item.seat);
				}
            })
        }
	});


    /**
     * 选择座位和取消座位
     */
    $(".primarySeatOfKongke,.normalSeatOfKongke").click(function () {
        var id = this.id.split("seat")[1];
        var flag = false;
        $.each(checkSeatList,function (i,item) {
            if (item == id){
                flag = true;
            }
        });

        if (flag == false){
            $("#"+this.id).css("background-color","yellow");
            checkSeatList.push(id);
        }else {
            if (this.className == "primarySeatOfKongke"){
                $("#"+this.id).css("background-color","red");
            }else {
                $("#"+this.id).css("background-color","#70C3A3");
            }

            checkSeatList.pop(id);
        }
    });







})